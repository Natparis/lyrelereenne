<?php
// Réglages Brevo enregistrés depuis l'administration du site.
// La clé est gardée sur le serveur (donnees-lyre/reglages.json.php) et n'est jamais renvoyée en entier.
// GET  reglages.php            + X-Code -> état (clé présente, 4 derniers caractères)
// POST reglages.php {action}   + X-Code -> action = enregistrer (cle), retirer, tester (expediteur)
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function out($code, $arr) { http_response_code($code); echo json_encode($arr, JSON_UNESCAPED_UNICODE); exit; }
$cfgFile = __DIR__ . '/config-site.php';
if (!is_file($cfgFile)) out(500, ['ok' => false, 'error' => 'Fichier config-site.php absent sur le serveur (voir LISEZ-MOI).']);
$cfg = require $cfgFile;
$real = (string)($cfg['code_bureau'] ?? '');
require __DIR__ . '/reglages-lib.php';
if (!lyre_bureau($cfg)) { sleep(1); out(401, ['ok' => false, 'error' => 'Accès refusé : reconnectez-vous.']); }
$fileKey = lyre_brevo_saved();
$cfgKey = (string)($cfg['brevo_key'] ?? '');
$key = $fileKey !== '' ? $fileKey : $cfgKey;
$etat = function () use (&$key, &$fileKey, $cfgKey) {
  return ['ok' => true, 'techSet' => lyre_tech_defini(), 'brevo' => $key !== '', 'fin' => $key !== '' ? substr($key, -4) : '', 'source' => $fileKey !== '' ? 'site' : ($cfgKey !== '' ? 'config' : '')];
};
function lyre_refus_droits($j) { $m = strtolower((string)(is_array($j) ? ($j['message'] ?? '') . ' ' . ($j['code'] ?? '') : '')); return (bool)preg_match('/permission|scope|not allowed|forbidden|restricted|access/', $m) && !preg_match('/key not found|invalid|disabled/', $m); }
$brevo = function ($k, $path) {
  $ch = curl_init('https://api.brevo.com/v3' . $path);
  curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_HTTPHEADER => ['api-key: ' . $k, 'Accept: application/json']]);
  $res = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
  return [$code, json_decode((string)$res, true)];
};

// Vérifie une clé : accès complet (/account) ou restreint aux e-mails transactionnels.
$verifier = function ($k) use ($brevo) {
  [$code, $j] = $brevo($k, '/account');
  if ($code >= 200 && $code < 300) return ['ok' => true, 'restreinte' => false, 'j' => $j];
  [$c2, $j2] = $brevo($k, '/smtp/statistics/aggregatedReport?days=1');
  if ($c2 >= 200 && $c2 < 300) return ['ok' => true, 'restreinte' => true, 'j' => []];
  $msg = trim((string)(is_array($j2) ? ($j2['message'] ?? '') : '')) ?: trim((string)(is_array($j) ? ($j['message'] ?? '') : ''));
  if ($code === 0 && $c2 === 0) return ['ok' => false, 'http' => 502, 'error' => 'Le serveur OVH n’arrive pas à joindre Brevo. Réessayez dans quelques minutes.'];
  if (preg_match('/unrecogni[sz]ed ip|ip address|authori[sz]ed ip|\bip\b/i', $msg)) {
    preg_match('/(\d{1,3}(?:\.\d{1,3}){3}|[0-9a-f]{0,4}(?::[0-9a-f]{0,4}){2,7})/i', $msg, $m);
    return ['ok' => false, 'http' => 400, 'ip' => $m[1] ?? '', 'error' => 'Brevo bloque l’adresse IP du serveur OVH' . (!empty($m[1]) ? ' (' . $m[1] . ')' : '') . '. Dans Brevo : menu de votre compte › Sécurité › IP autorisées, ajoutez cette adresse (ou désactivez le blocage des IP inconnues), puis recommencez. Message de Brevo : « ' . $msg . ' »'];
  }
  if ($code === 401 || $c2 === 401) return ['ok' => false, 'http' => 400, 'error' => 'Brevo refuse cette clé' . ($msg ? ' : « ' . $msg . ' »' : '') . '. Vérifiez qu’elle est copiée en entier, active, et que « Emails transactionnels » est sur « Tous ».'];
  return ['ok' => false, 'http' => 502, 'error' => 'Réponse inattendue de Brevo (code ' . $code . '/' . $c2 . ')' . ($msg ? ' : « ' . $msg . ' »' : '') . '.'];
};

if ($_SERVER['REQUEST_METHOD'] === 'GET') out(200, $etat());
if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(405, ['ok' => false, 'error' => 'Méthode non prise en charge.']);
$in = json_decode(file_get_contents('php://input'), true);
$action = is_array($in) ? (string)($in['action'] ?? '') : '';
$tech = isset($_SERVER['HTTP_X_CODE_TECH']) ? (string)$_SERVER['HTTP_X_CODE_TECH'] : '';
if ($action === 'creer') {
  if (lyre_tech_defini()) out(409, ['ok' => false, 'error' => 'Le code des réglages existe déjà : saisissez-le pour déverrouiller.']);
  $c = (string)($in['tech'] ?? '');
  if (strlen($c) < 6) out(400, ['ok' => false, 'error' => 'Choisissez un code d’au moins 6 caractères.']);
  if (hash_equals($real, $c)) out(400, ['ok' => false, 'error' => 'Choisissez un code différent du code du bureau.']);
  if (!lyre_tech_creer($c)) out(500, ['ok' => false, 'error' => 'Écriture impossible sur le serveur (droits du dossier donnees-lyre).']);
  out(200, $etat());
}
if ($action === 'verifier') {
  if (!lyre_tech_ok((string)($in['tech'] ?? ''))) { sleep(1); out(403, ['ok' => false, 'error' => 'Code des réglages incorrect.']); }
  out(200, $etat());
}
// Toutes les autres actions demandent le code des réglages.
if (!lyre_tech_ok($tech)) { sleep(1); out(403, ['ok' => false, 'error' => lyre_tech_defini() ? 'Réglages verrouillés : déverrouillez-les avec le code des réglages.' : 'Créez d’abord le code des réglages.']); }

if ($action === 'enregistrer') {
  $k = trim((string)($in['cle'] ?? ''));
  if (!preg_match('/^xkeysib-[A-Za-z0-9-]{20,}$/', $k)) out(400, ['ok' => false, 'error' => 'Ce n’est pas une clé API Brevo (elle commence par « xkeysib- »). Une clé SMTP ou MCP ne convient pas.']);
  $v = $verifier($k);
  if (!$v['ok']) out($v['http'], ['ok' => false, 'error' => $v['error'], 'ip' => $v['ip'] ?? '']);
  $restreinte = $v['restreinte']; $j = $v['j'];
  if (!lyre_brevo_save($k)) out(500, ['ok' => false, 'error' => 'Écriture impossible sur le serveur (droits du dossier donnees-lyre).']);
  $key = $k; $fileKey = $k;
  out(200, $etat() + ['compte' => $restreinte ? '' : (string)($j['email'] ?? ''), 'restreinte' => $restreinte]);
}
if ($action === 'retirer') {
  lyre_brevo_save('');
  $fileKey = ''; $key = $cfgKey;
  out(200, $etat());
}
if ($action === 'tester') {
  if ($key === '') out(400, ['ok' => false, 'error' => 'Aucune clé Brevo enregistrée.']);
  $v = $verifier($key);
  if (!$v['ok']) out($v['http'], ['ok' => false, 'error' => $v['error'], 'ip' => $v['ip'] ?? '']);
  $restreinte = $v['restreinte']; $j = $v['j'];
  $credits = '';
  foreach ((array)($j['plan'] ?? []) as $p) { if (($p['creditsType'] ?? '') === 'sendLimit' && isset($p['credits'])) $credits = (string)$p['credits']; }
  $exp = strtolower(trim((string)($in['expediteur'] ?? '')));
  $expOk = null;
  if ($exp !== '') {
    [$c2, $s] = $brevo($key, '/senders');
    if ($c2 === 401 || $c2 === 403) $expOk = 'inconnu';
    elseif ($c2 >= 200 && $c2 < 300) { $expOk = false; foreach ((array)($s['senders'] ?? []) as $x) { if (strtolower((string)($x['email'] ?? '')) === $exp && !empty($x['active'])) $expOk = true; } }
  }
  out(200, $etat() + ['restreinte' => $restreinte, 'compte' => $restreinte ? '' : (string)($j['email'] ?? ''), 'credits' => $credits, 'expediteur' => $exp, 'expediteurOk' => $expOk]);
}
out(400, ['ok' => false, 'error' => 'Action inconnue.']);
