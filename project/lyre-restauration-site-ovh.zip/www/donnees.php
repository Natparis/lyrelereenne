<?php
// Stockage des données du site sur l'hébergement OVH (sans base de données).
// GET  donnees.php?part=public          -> lecture publique (actus, agenda, photos, tarifs…)
// GET  donnees.php?part=prive  + X-Code -> lecture réservée au bureau (membres, élèves, compta, e-mails…)
// GET  …&rev=1                          -> seulement le numéro de version (pour savoir si quelqu'un a enregistré)
// POST donnees.php?part=public|prive + X-Code, corps {"data": {...}, "base": "version lue", "verrou": true}
//      -> enregistre seulement si personne n'a enregistré depuis la version « base » ; sinon répond 409
//         avec les données actuelles, et le site fusionne puis renvoie. Aucune saisie n'est écrasée.
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function out($code, $arr) { http_response_code($code); echo json_encode($arr, JSON_UNESCAPED_UNICODE); exit; }

$cfgFile = __DIR__ . '/config-site.php';
if (!is_file($cfgFile)) out(500, ['ok' => false, 'error' => 'Fichier config-site.php absent sur le serveur (voir LISEZ-MOI).']);
$cfg = require $cfgFile;
require __DIR__ . '/reglages-lib.php';
// Accès du bureau : compte connecté (jeton de session) ou code du serveur.
$codeOk = function () use ($cfg) { return (bool)lyre_bureau($cfg); };

$part = isset($_GET['part']) ? $_GET['part'] : '';
if (!in_array($part, ['public', 'prive', 'membres'], true)) out(400, ['ok' => false, 'error' => 'Partie inconnue.']);
// « membres » = espace membres : lisible par les membres connectés, modifiable en entier par le bureau seulement.
$moi = $part === 'membres' ? lyre_membre() : null;
$dir = __DIR__ . '/donnees-lyre';
if (!is_dir($dir)) @mkdir($dir, 0750, true);
$file = $dir . '/' . $part . '.json.php';
$GARDE = "<?php http_response_code(403); exit; ?>\n";
$lire = function ($f) use ($GARDE) { if (!is_file($f)) return ''; $r = (string)file_get_contents($f); return strpos($r, $GARDE) === 0 ? substr($r, strlen($GARDE)) : $r; };
$rev = function ($json) { return $json === '' ? '' : md5($json); };
$brut = function ($json) { return ($json !== '' && $json[0] === '{' && is_array(json_decode($json, true))) ? $json : '{}'; };

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
  if (($part === 'prive' && !$codeOk()) || ($part === 'membres' && !$codeOk() && $moi === null)) { sleep(1); out(401, ['ok' => false, 'error' => 'Accès refusé : reconnectez-vous.']); }
  $raw = $lire($file);
  if (!empty($_GET['rev'])) out(200, ['ok' => true, 'rev' => $rev($raw)]);
  // Les données sont renvoyées telles qu'elles ont été enregistrées (objets vides conservés).
  echo '{"ok":true,"rev":"' . $rev($raw) . '","at":' . (is_file($file) ? filemtime($file) : 0) . ',"data":' . $brut($raw) . '}'; exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $bureau = $codeOk();
  if (!$bureau && $moi === null) { sleep(1); out(401, ['ok' => false, 'error' => 'Accès refusé : reconnectez-vous.']); }
  $body = json_decode(file_get_contents('php://input'), true);
  if (!is_array($body)) out(400, ['ok' => false, 'error' => 'Données illisibles ou trop volumineuses.']);
  if (isset($body['json']) && is_string($body['json'])) { $json = $body['json']; if (!is_array(json_decode($json, true)) || $json[0] !== '{') out(400, ['ok' => false, 'error' => 'Données illisibles.']); }
  elseif (isset($body['data']) && is_array($body['data'])) { $json = json_encode($body['data'], JSON_UNESCAPED_UNICODE); if ($json === false) out(400, ['ok' => false, 'error' => 'Données illisibles.']); }
  else out(400, ['ok' => false, 'error' => 'Données illisibles.']);
  // Un seul enregistrement à la fois.
  $lock = @fopen($dir . '/verrou.lock', 'c');
  if (!$lock || !flock($lock, LOCK_EX)) out(503, ['ok' => false, 'error' => 'Serveur occupé, nouvel essai automatique.']);
  $actuel = $lire($file);
  if (!empty($body['verrou']) && (string)($body['base'] ?? '') !== $rev($actuel)) {
    flock($lock, LOCK_UN); fclose($lock);
    http_response_code(409); echo '{"ok":false,"error":"Une autre personne a enregistré entre-temps.","rev":"' . $rev($actuel) . '","data":' . $brut($actuel) . '}'; exit;
  }
  $modifie = false;
  if ($part === 'membres') {
    if (!$bureau) { $obj = lyre_membre_filtre($actuel, $json, $moi); $modifie = true; }
    else { $obj = json_decode($json); }
    if (is_object($obj)) { if (lyre_codes_extraire($obj, $bureau ? null : $moi)) $modifie = true; if ($modifie) { $json = json_encode($obj, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); $modifie = ($json !== (string)($body['json'] ?? '')); } }
  }
  $fin = function ($code, $rev, $json, $modifie, $file) { http_response_code($code); echo '{"ok":true,"rev":"' . $rev . '","at":' . (is_file($file) ? filemtime($file) : 0) . ($modifie ? ',"data":' . $json : '') . '}'; exit; };
  if ($json === $actuel) { flock($lock, LOCK_UN); fclose($lock); $fin(200, $rev($actuel), $json, $modifie, $file); }
  // Sauvegarde de la version précédente (60 dernières gardées).
  if (is_file($file)) {
    $bdir = $dir . '/sauvegardes';
    if (!is_dir($bdir)) @mkdir($bdir, 0750, true);
    @copy($file, $bdir . '/' . $part . '-' . date('Ymd-His') . '-' . substr($rev($actuel), 0, 6) . '.json.php');
    $old = glob($bdir . '/' . $part . '-*.json.php'); sort($old);
    while (count($old) > 60) @unlink(array_shift($old));
  }
  $tmp = $file . '.tmp.php';
  $ok = file_put_contents($tmp, $GARDE . $json) !== false && rename($tmp, $file);
  flock($lock, LOCK_UN); fclose($lock);
  if (!$ok) out(500, ['ok' => false, 'error' => "Écriture impossible sur le serveur (droits du dossier donnees-lyre)."]);
  $fin(200, $rev($json), $json, $modifie, $file);
}
out(405, ['ok' => false, 'error' => 'Méthode non prise en charge.']);
