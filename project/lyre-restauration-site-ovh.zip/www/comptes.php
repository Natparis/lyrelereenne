<?php
// Comptes du bureau : les mots de passe sont vérifiés ici, sur le serveur, et gardés chiffrés.
// POST comptes.php {action: etat | initialiser | connexion | liste | enregistrer | journal_vider}
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function out($code, $arr) { http_response_code($code); echo json_encode($arr, JSON_UNESCAPED_UNICODE); exit; }
$cfgFile = __DIR__ . '/config-site.php';
if (!is_file($cfgFile)) out(500, ['ok' => false, 'error' => 'Fichier config-site.php absent sur le serveur (voir LISEZ-MOI).']);
$cfg = require $cfgFile;
require __DIR__ . '/reglages-lib.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(405, ['ok' => false, 'error' => 'Méthode non prise en charge.']);
$in = json_decode(file_get_contents('php://input'), true);
$action = is_array($in) ? (string)($in['action'] ?? '') : '';
$C = lyre_comptes();
$liste = function ($C) { return array_map('lyre_compte_public', $C['comptes']); };
$nettoie = function ($a) { return ['id' => preg_replace('/[^A-Za-z0-9_-]/', '', (string)($a['id'] ?? '')), 'name' => trim((string)($a['name'] ?? '')), 'role' => trim((string)($a['role'] ?? '')), 'login' => strtolower(trim((string)($a['login'] ?? ''))), 'email' => strtolower(trim((string)($a['email'] ?? ''))), 'active' => !empty($a['active']), 'access' => array_values(array_filter(array_map('strval', (array)($a['access'] ?? []))))]; };

if ($action === 'etat') out(200, ['ok' => true, 'pret' => (bool)$C]);

if ($action === 'initialiser') {
  // Première mise en place : envoi des comptes existants, avec le code du serveur.
  $qui = lyre_bureau($cfg);
  if (!$qui || $qui['via'] !== 'code') { sleep(1); out(401, ['ok' => false, 'error' => 'Code du serveur incorrect.']); }
  $l = lyre_verrou(); $C = lyre_comptes();
  if ($C) { lyre_deverrou($l); out(200, ['ok' => true, 'pret' => true, 'deja' => true]); }
  $res = [];
  foreach ((array)($in['comptes'] ?? []) as $a) { $c = $nettoie($a); $pwd = (string)($a['pwd'] ?? ''); if ($c['id'] === '' || $c['login'] === '' || $pwd === '') continue;
    $c['hash'] = password_hash($pwd, PASSWORD_DEFAULT); $c['defaut'] = ($pwd === 'lyre2026'); $c['lastLogin'] = (string)($a['lastLogin'] ?? ''); $res[] = $c; }
  $aDroits = false; foreach ($res as $c) if ($c['active'] && in_array('droits', $c['access'], true)) $aDroits = true;
  if (!$res || !$aDroits) { lyre_deverrou($l); out(400, ['ok' => false, 'error' => 'Il faut au moins un compte actif ayant accès à « Comptes et droits ».']); }
  $ok = lyre_fichier_ecrire('comptes', ['comptes' => $res, 'journal' => []]); lyre_deverrou($l);
  out($ok ? 200 : 500, $ok ? ['ok' => true, 'pret' => true] : ['ok' => false, 'error' => 'Écriture impossible sur le serveur.']);
}

if (!$C) out(409, ['ok' => false, 'pret' => false, 'error' => 'Les comptes ne sont pas encore installés sur le serveur.']);

if ($action === 'connexion') {
  $login = strtolower(trim((string)($in['login'] ?? ''))); $pwd = (string)($in['pwd'] ?? '');
  $cle = lyre_ip() . '|' . $login;
  if (!lyre_essais($cle)) out(429, ['ok' => false, 'error' => 'Trop d’essais. Réessayez dans un quart d’heure.']);
  $l = lyre_verrou(); $C = lyre_comptes(); $u = null; $i = -1;
  foreach ($C['comptes'] as $k => $x) if ($x['login'] === $login) { $u = $x; $i = $k; }
  // Connexion possible avec l'adresse e-mail : celle du compte, sinon celle de la fiche membre de la même personne.
  if (!$u && strpos($login, '@') !== false) {
    $t = []; foreach ($C['comptes'] as $k => $x) if (($x['email'] ?? '') !== '' && $x['email'] === $login) $t[] = $k;
    if (!$t) { $noms = []; foreach (lyre_annuaire() as $m) if (strtolower(trim((string)($m['email'] ?? ''))) === $login) $noms[] = lyre_norm(($m['prenom'] ?? '') . ' ' . ($m['nom'] ?? ''));
      foreach ($C['comptes'] as $k => $x) if (in_array(lyre_norm($x['name']), $noms, true)) $t[] = $k; }
    if (count($t) === 1) { $i = $t[0]; $u = $C['comptes'][$i]; }
  }
  $bon = $u && password_verify($pwd, (string)$u['hash']);
  $res = !$u ? 'identifiant inconnu' : (!$bon ? 'mot de passe incorrect' : (empty($u['active']) ? 'compte désactivé' : 'connexion réussie'));
  $okFinal = $bon && !empty($u['active']);
  array_unshift($C['journal'], ['at' => gmdate('c'), 'name' => $u ? $u['name'] : '', 'login' => substr($login, 0, 60), 'ok' => $okFinal, 'result' => $res]);
  $C['journal'] = array_slice($C['journal'], 0, 200);
  if ($okFinal) $C['comptes'][$i]['lastLogin'] = gmdate('c');
  lyre_fichier_ecrire('comptes', $C); lyre_deverrou($l);
  if (!$okFinal) { lyre_essais($cle, true); sleep(1); out(401, ['ok' => false, 'error' => $bon ? 'Ce compte est désactivé. Contactez le président.' : 'Identifiant ou mot de passe incorrect.']); }
  lyre_essais($cle, false);
  $peutDroits = in_array('droits', (array)$u['access'], true);
  out(200, ['ok' => true, 'jeton' => lyre_jeton('b', $u['id'], 16), 'compte' => lyre_compte_public($C['comptes'][$i]), 'comptes' => $liste($C), 'journal' => $peutDroits ? $C['journal'] : []]);
}

$qui = lyre_bureau($cfg);
if (!$qui) { sleep(1); out(401, ['ok' => false, 'error' => 'Session expirée : reconnectez-vous.']); }

if ($action === 'liste') out(200, ['ok' => true, 'comptes' => $liste($C), 'journal' => lyre_droit($qui, 'droits') ? $C['journal'] : []]);

if (!lyre_droit($qui, 'droits')) out(403, ['ok' => false, 'error' => 'Votre compte ne donne pas accès à « Comptes et droits ».']);

if ($action === 'enregistrer') {
  $l = lyre_verrou(); $C = lyre_comptes(); $anc = []; foreach ($C['comptes'] as $x) $anc[$x['id']] = $x;
  $res = []; $logins = [];
  foreach ((array)($in['comptes'] ?? []) as $a) { $c = $nettoie($a); $pwd = (string)($a['pwd'] ?? '');
    if ($c['id'] === '' || $c['login'] === '' || $c['name'] === '') continue;
    if ($c['email'] !== '' && !filter_var($c['email'], FILTER_VALIDATE_EMAIL)) { lyre_deverrou($l); out(400, ['ok' => false, 'error' => 'Adresse e-mail invalide pour ' . $c['name'] . '.']); }
    if (isset($logins[$c['login']])) { lyre_deverrou($l); out(400, ['ok' => false, 'error' => 'Deux comptes ont le même identifiant : ' . $c['login']]); } $logins[$c['login']] = 1;
    $o = $anc[$c['id']] ?? null;
    if ($pwd !== '') { if (strlen($pwd) < 6) { lyre_deverrou($l); out(400, ['ok' => false, 'error' => 'Le mot de passe doit faire au moins 6 caractères.']); } $c['hash'] = password_hash($pwd, PASSWORD_DEFAULT); $c['defaut'] = ($pwd === 'lyre2026'); }
    elseif ($o) { $c['hash'] = $o['hash']; $c['defaut'] = !empty($o['defaut']); }
    else { lyre_deverrou($l); out(400, ['ok' => false, 'error' => 'Choisissez un mot de passe pour le nouveau compte.']); }
    $c['lastLogin'] = $o['lastLogin'] ?? ''; $res[] = $c; }
  $aDroits = false; foreach ($res as $c) if ($c['active'] && in_array('droits', $c['access'], true)) $aDroits = true;
  if (!$aDroits) { lyre_deverrou($l); out(400, ['ok' => false, 'error' => 'Gardez au moins un compte actif ayant accès à « Comptes et droits ».']); }
  $C['comptes'] = $res; $ok = lyre_fichier_ecrire('comptes', $C); lyre_deverrou($l);
  out($ok ? 200 : 500, $ok ? ['ok' => true, 'comptes' => $liste($C)] : ['ok' => false, 'error' => 'Écriture impossible sur le serveur.']);
}
if ($action === 'journal_vider') { $l = lyre_verrou(); $C = lyre_comptes(); $C['journal'] = []; lyre_fichier_ecrire('comptes', $C); lyre_deverrou($l); out(200, ['ok' => true]); }
out(400, ['ok' => false, 'error' => 'Action inconnue.']);
